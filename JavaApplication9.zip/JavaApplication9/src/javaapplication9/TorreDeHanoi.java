
package javaapplication9;
import java.io.*;
import java.util.*;

class Disco {
    int tamaño;
    Disco siguiente;
    
    Disco(int tamaño) {
        this.tamaño = tamaño;
    }
}

class Torre {
    private Disco cima;
    
    public void apilar(Disco disco) {
        disco.siguiente = cima;
        cima = disco;
    }
    
    public Disco desapilar() {
        if (cima == null) return null;
        Disco disco = cima;
        cima = cima.siguiente;
        disco.siguiente = null;
        return disco;
    }
    
    public boolean estaVacia() {
        return cima == null;
    }
    
    public Disco verCima() {
        return cima;
    }
}

public class TorreDeHanoi {
    private static Torre torreA = new Torre();
    private static Torre torreB = new Torre();
    private static Torre torreC = new Torre();
    private static int totalMovimientos = 0;

    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el número de discos:");
        int n = scanner.nextInt();
        
        // Crear y mezclar discos
        Disco[] discos = new Disco[n];
        for (int i = 0; i < n; i++) {
            discos[i] = new Disco(n - i);
        }
        mezclar(discos);
        for (Disco disco : discos) {
            torreA.apilar(disco);
        }
        
        // Jugar
        while (!juegoCompletado(torreC, n)) {
            mostrarTorres();
            char origen = obtenerTorreValida(scanner, "origen");
            char destino = obtenerTorreValida(scanner, "destino");
            
            moverDisco(obtenerTorre(origen), obtenerTorre(destino));
            totalMovimientos++;
        }
        
        mostrarTorres();
        System.out.println("¡Juego completado en " + totalMovimientos + " movimientos!");
        
        // Guardar puntajes
        System.out.println("Ingrese su nombre:");
        String nombre = scanner.next();
        guardarPuntaje(nombre, totalMovimientos);
        
        mostrarMejoresPuntajes();
    }
    
    private static Torre obtenerTorre(char letra) {
        switch (letra) {
            case 'A': return torreA;
            case 'B': return torreB;
            case 'C': return torreC;
            default: return null;
        }
    }
    
    private static void moverDisco(Torre origen, Torre destino) {
        if (origen.estaVacia()) {
            System.out.println("Movimiento no válido, torre de origen vacía");
            return;
        }
        Disco disco = origen.desapilar();
        if (destino.estaVacia() || disco.tamaño < destino.verCima().tamaño) {
            destino.apilar(disco);
        } else {
            System.out.println("Movimiento no válido, disco más grande sobre uno más pequeño");
            origen.apilar(disco);
        }
    }
    
    private static void mezclar(Disco[] discos) {
        Random random = new Random();
        for (int i = discos.length - 1; i > 0; i--) {
            int index = random.nextInt(i + 1);
            Disco temp = discos[index];
            discos[index] = discos[i];
            discos[i] = temp;
        }
    }
    
    private static boolean juegoCompletado(Torre torre, int n) {
        int count = 0;
        Disco current = torre.verCima();
        while (current != null) {
            count++;
            current = current.siguiente;
        }
        return count == n;
    }
    
    private static void mostrarTorres() {
        System.out.println("Torre A:");
        mostrarTorre(torreA);
        System.out.println("Torre B:");
        mostrarTorre(torreB);
        System.out.println("Torre C:");
        mostrarTorre(torreC);
    }
    
    private static void mostrarTorre(Torre torre) {
        Disco current = torre.verCima();
        while (current != null) {
            System.out.print(current.tamaño + " ");
            current = current.siguiente;
        }
        System.out.println();
    }
    
    private static void guardarPuntaje(String nombre, int movimientos) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter("puntuaciones.txt", true));
        writer.write(nombre + ": " + movimientos + "\n");
        writer.close();
    }
    
    private static void mostrarMejoresPuntajes() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader("puntuaciones.txt"));
        List<String> lineas = new ArrayList<>();
        String linea;
        while ((linea = reader.readLine()) != null) {
            lineas.add(linea);
        }
        reader.close();
        
        lineas.sort((a, b) -> {
            int puntajeA = Integer.parseInt(a.split(": ")[1]);
            int puntajeB = Integer.parseInt(b.split(": ")[1]);
            return Integer.compare(puntajeA, puntajeB);
        });
        
        System.out.println("Las 10 mejores puntuaciones:");
        for (int i = 0; i < Math.min(10, lineas.size()); i++) {
            System.out.println((i + 1) + ". " + lineas.get(i));
        }
    }
    
    private static char obtenerTorreValida(Scanner scanner, String tipo) {
        char torre;
        while (true) {
            System.out.println("Ingrese la torre de " + tipo + " (A, B, C):");
            torre = scanner.next().charAt(0);
            if (torre == 'A' || torre == 'B' || torre == 'C') {
                break;
            } else {
                System.out.println("Entrada no válida. Por favor, ingrese 'A', 'B' o 'C'.");
            }
        }
        return torre;
    }
}
